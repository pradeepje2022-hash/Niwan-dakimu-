package com.niwandakimu.app.data

/**
 * A single video/upload/live-stream entry from the Niwan Dakimu channel feed.
 */
data class Video(
    val videoId: String,
    val title: String,
    val description: String,
    val thumbnailUrl: String,
    val publishedAt: String,
    val channelTitle: String = "Niwan Dakimu",
    val watchUrl: String,
    val isLive: Boolean = false
)
