# Niwan Dakimu — Android App

Kotlin + Jetpack Compose (MVVM) app for the **Niwan Dakimu** YouTube channel:
video feed, background audio playback (Media3/ExoPlayer + foreground service),
playback speed control, playlists, "Play Next" queue, and a Downloads tab.

## ⚠️ Important: about YouTube content & this app's limits

This project is built to be 100% compliant with YouTube's Terms of Service:

1. **Video feed** — uses YouTube's public RSS endpoint (no API key, no quota).
   Optionally, `YouTubeApiService.kt` adds Data API v3 support for live-stream
   detection (needs a key).
2. **Actual video/audio playback of YouTube uploads** — YouTube does not allow
   apps to extract raw stream URLs from its videos, and forbids background
   audio-only playback / offline downloads outside their own app. This repo's
   playback and download pipeline (Media3 + WorkManager) is fully built and
   works with **any direct media URL**. To play/download the real Niwan Dakimu
   videos inside this app without violating YouTube's terms, you have two
   supported options:
   - Embed the official **YouTube Android Player API / IFrame player**
     (`YouTubePlayerView`) for in-app playback — this keeps you within
     YouTube's rules, but background-audio-only and download are not
     permitted for that embedded player.
   - If Niwan Dakimu wants true background playback + offline downloads,
     publish the audio/video as separate direct files (e.g. hosted on your own
     CDN, Google Drive direct-link, or a podcast host) — this app's
     `PlayerController` and `DownloadWorker` will work with those URLs as-is.

Everything else in this project (UI, database, download manager, background
service, playlists, queue, CI) is complete and production-ready.

## 1. Find the channel ID

The RSS feed needs the numeric channel ID (`UC...`), not the `@NiwanDakimu`
handle:
1. Open `https://www.youtube.com/NiwanDakimu`
2. View page source → search for `"channelId"` → copy the `UC...` value.
3. Paste it into `NiwanDakimuApp.kt`:
   ```kotlin
   val channelId = "UCxxxxxxxxxxxxxxxxxxxxxx"
   ```

## 2. Open in Android Studio

1. Android Studio Koala (2024.1) or newer, JDK 17.
2. `File → Open` → select the `NiwanDakimu/` folder.
3. Let Gradle sync (first sync downloads the wrapper if `gradlew` is missing —
   if so, run `gradle wrapper --gradle-version 8.7` once from a terminal with
   Gradle installed, or let Android Studio's "Fix Gradle wrapper" prompt do it).
4. Run on a device/emulator with the ▶️ button.

## 3. (Optional) Add a YouTube Data API v3 key

Only needed for live-stream detection:
1. https://console.cloud.google.com/apis/credentials → enable **YouTube Data
   API v3** → create an API key.
2. In `local.properties` (not committed to git) add:
   ```
   YT_API_KEY=your_key_here
   ```
3. It's wired into `BuildConfig.YT_API_KEY` automatically via `build.gradle.kts`.

## 4. Generate a signed release APK locally

```bash
keytool -genkeypair -v -keystore release.keystore -alias niwandakimu \
  -keyalg RSA -keysize 2048 -validity 10000
```
Then in Android Studio: `Build → Generate Signed Bundle / APK → APK`, point it
at `release.keystore`, and build the release variant.

## 5. Build the APK automatically with GitHub Actions

This repo includes `.github/workflows/build.yml`:

- **Every push to `main`** → builds a debug APK, uploaded as a workflow
  artifact (Actions tab → latest run → Artifacts → `niwan-dakimu-debug-apk`).
- **Pushing a tag like `v1.0.0`** → builds a signed release APK and attaches
  it to a GitHub Release automatically.

### One-time setup for signed release builds
In your GitHub repo: **Settings → Secrets and variables → Actions**, add:

| Secret name | Value |
|---|---|
| `SIGNING_KEYSTORE_BASE64` | `base64 -i release.keystore` output |
| `SIGNING_STORE_PASSWORD` | your keystore password |
| `SIGNING_KEY_ALIAS` | `niwandakimu` (or whatever alias you used) |
| `SIGNING_KEY_PASSWORD` | your key password |
| `YT_API_KEY` | (optional) Data API v3 key |

Then:
```bash
git tag v1.0.0
git push origin v1.0.0
```
GitHub Actions builds the signed APK and publishes it under **Releases** —
download it straight to any Android phone.

## Project structure

```
app/src/main/java/com/niwandakimu/app/
 ├── MainActivity.kt          # Compose scaffold + bottom nav
 ├── MainViewModel.kt         # Feed, playlists, queue, downloads, speed
 ├── NiwanDakimuApp.kt        # Simple service locator (DB, repo, player)
 ├── data/
 │   ├── Video.kt
 │   ├── ChannelFeedRepository.kt   # RSS feed parser (no API key)
 │   ├── YouTubeApiService.kt       # Optional Data API v3 (live streams)
 │   └── db/                        # Room: playlists, queue, downloads
 ├── playback/
 │   ├── PlaybackService.kt   # Media3 MediaSessionService (background audio)
 │   └── PlayerController.kt  # MediaController wrapper used by the ViewModel
 ├── download/
 │   └── DownloadWorker.kt    # WorkManager download with progress
 └── ui/
     ├── theme/                # Material3 calming color palette + type
     └── screens/              # Home, Playlists, Queue, Downloads
```
