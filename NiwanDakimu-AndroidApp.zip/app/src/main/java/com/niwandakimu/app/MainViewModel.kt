package com.niwandakimu.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.niwandakimu.app.data.Video
import com.niwandakimu.app.data.db.PlaylistEntity
import com.niwandakimu.app.data.db.PlaylistItemEntity
import com.niwandakimu.app.data.db.QueueItemEntity
import com.niwandakimu.app.download.DownloadWorker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(private val app: NiwanDakimuApp) : ViewModel() {

    private val _videos = MutableStateFlow<List<Video>>(emptyList())
    val videos: StateFlow<List<Video>> = _videos.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    val playlists = app.database.playlistDao().getPlaylists()
    val queue = app.database.queueDao().getQueue()
    val downloads = app.database.downloadDao().getDownloads()

    init {
        refreshFeed()
        app.playerController.connect { }
    }

    fun refreshFeed() = viewModelScope.launch {
        _isLoading.value = true
        _videos.value = app.feedRepository.fetchLatestVideos()
        _isLoading.value = false
    }

    fun play(video: Video, streamUrl: String) {
        app.playerController.playVideo(video.videoId, video.title, streamUrl, video.thumbnailUrl)
    }

    fun togglePlayPause() = app.playerController.togglePlayPause()

    fun setSpeed(speed: Float) {
        _playbackSpeed.value = speed
        app.playerController.setPlaybackSpeed(speed)
    }

    fun addToQueueNext(video: Video, streamUrl: String) = viewModelScope.launch {
        app.database.queueDao().addToQueue(
            QueueItemEntity(
                videoId = video.videoId, title = video.title,
                thumbnailUrl = video.thumbnailUrl, watchUrl = video.watchUrl, position = 0
            )
        )
        app.playerController.playNext(video.videoId, video.title, streamUrl)
    }

    fun createPlaylist(name: String) = viewModelScope.launch {
        app.database.playlistDao().createPlaylist(PlaylistEntity(name = name))
    }

    fun addToPlaylist(playlistId: Long, video: Video, position: Int) = viewModelScope.launch {
        app.database.playlistDao().addItem(
            PlaylistItemEntity(
                playlistId = playlistId, videoId = video.videoId, title = video.title,
                thumbnailUrl = video.thumbnailUrl, watchUrl = video.watchUrl, position = position
            )
        )
    }

    /** sourceUrl must be a direct, licensed media file - see DownloadWorker doc comment. */
    fun downloadVideo(video: Video, sourceUrl: String) {
        val data = Data.Builder()
            .putString(DownloadWorker.KEY_VIDEO_ID, video.videoId)
            .putString(DownloadWorker.KEY_TITLE, video.title)
            .putString(DownloadWorker.KEY_THUMB, video.thumbnailUrl)
            .putString(DownloadWorker.KEY_SOURCE_URL, sourceUrl)
            .build()
        val request = OneTimeWorkRequestBuilder<DownloadWorker>()
            .setInputData(data)
            .build()
        WorkManager.getInstance(app).enqueue(request)
    }

    override fun onCleared() {
        app.playerController.release()
        super.onCleared()
    }
}
