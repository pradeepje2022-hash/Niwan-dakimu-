package com.niwandakimu.app.data

import retrofit2.http.GET
import retrofit2.http.Query

/**
 * Optional: only needed if you want to detect active live streams (RSS doesn't
 * expose live status). Requires a YouTube Data API v3 key with a daily quota.
 * Get one at https://console.cloud.google.com/apis/credentials after enabling
 * "YouTube Data API v3" on your project.
 */
interface YouTubeApiService {

    @GET("search")
    suspend fun searchLive(
        @Query("channelId") channelId: String,
        @Query("eventType") eventType: String = "live",
        @Query("type") type: String = "video",
        @Query("part") part: String = "snippet",
        @Query("key") apiKey: String
    ): SearchResponse

    data class SearchResponse(val items: List<SearchItem>)
    data class SearchItem(val id: VideoIdHolder, val snippet: Snippet)
    data class VideoIdHolder(val videoId: String)
    data class Snippet(
        val title: String,
        val description: String,
        val publishedAt: String,
        val thumbnails: Thumbnails
    )
    data class Thumbnails(val high: ThumbnailUrl)
    data class ThumbnailUrl(val url: String)
}
