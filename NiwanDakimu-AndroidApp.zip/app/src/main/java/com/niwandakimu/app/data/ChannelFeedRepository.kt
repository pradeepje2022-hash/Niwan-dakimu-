package com.niwandakimu.app.data

import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader

/**
 * Pulls the channel's public upload feed via YouTube's official RSS endpoint.
 * This requires ZERO API key/quota and is the officially supported way for
 * unauthenticated apps to list a channel's recent uploads.
 *
 * Endpoint reference: https://www.youtube.com/feeds/videos.xml?channel_id=<ID>
 *
 * NOTE: You must resolve "Niwan Dakimu" 's channel ID once (starts with "UC...").
 * Easiest way: open https://www.youtube.com/NiwanDakimu -> view page source ->
 * search for "channelId", or use https://commentpicker.com/youtube-channel-id.php
 * Paste it below or pass it in via BuildConfig/remote config.
 */
class ChannelFeedRepository(
    private val channelId: String
) {
    private val client = OkHttpClient()

    suspend fun fetchLatestVideos(): List<Video> = withContext(Dispatchers.IO) {
        val url = "https://www.youtube.com/feeds/videos.xml?channel_id=$channelId"
        val request = Request.Builder().url(url).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext emptyList()
            val body = response.body?.string() ?: return@withContext emptyList()
            parseFeed(body)
        }
    }

    private fun parseFeed(xml: String): List<Video> {
        val videos = mutableListOf<Video>()
        val parser: XmlPullParser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        parser.setInput(StringReader(xml))

        var eventType = parser.eventType
        var videoId = ""
        var title = ""
        var published = ""
        var thumbnail = ""
        var inEntry = false

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "entry" -> {
                            inEntry = true
                            videoId = ""; title = ""; published = ""; thumbnail = ""
                        }
                        "yt:videoId" -> if (inEntry) videoId = parser.nextText()
                        "title" -> if (inEntry) title = parser.nextText()
                        "published" -> if (inEntry) published = parser.nextText()
                        "media:thumbnail" -> if (inEntry) {
                            thumbnail = parser.getAttributeValue(null, "url") ?: ""
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name == "entry" && inEntry) {
                        if (videoId.isNotBlank()) {
                            videos.add(
                                Video(
                                    videoId = videoId,
                                    title = title,
                                    description = "",
                                    thumbnailUrl = thumbnail.ifBlank {
                                        "https://i.ytimg.com/vi/$videoId/hqdefault.jpg"
                                    },
                                    publishedAt = published,
                                    watchUrl = "https://www.youtube.com/watch?v=$videoId"
                                )
                            )
                        }
                        inEntry = false
                    }
                }
            }
            eventType = parser.next()
        }
        return videos
    }
}
