package com.niwandakimu.app.ui.theme

import androidx.compose.ui.graphics.Color

// Calming sage / temple-gold palette
val SagePrimary = Color(0xFF5A7D6A)
val SagePrimaryDark = Color(0xFFA8C4B4)
val TempleGold = Color(0xFFC9A24B)
val TempleGoldDark = Color(0xFFE4C97A)
val DeepIndigo = Color(0xFF2E3A46)
val MistBackground = Color(0xFFF4F6F3)
val MistSurface = Color(0xFFFFFFFF)
val NightBackground = Color(0xFF15191A)
val NightSurface = Color(0xFF1E2423)
val SoftError = Color(0xFFB3261E)
