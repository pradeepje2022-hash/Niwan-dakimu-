package com.niwandakimu.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.niwandakimu.app.MainViewModel
import com.niwandakimu.app.data.Video

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: MainViewModel) {
    val videos by viewModel.videos.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    var speedDialogVideo by remember { mutableStateOf<Video?>(null) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Niwan Dakimu") }) }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            if (isLoading && videos.isEmpty()) {
                CircularProgressIndicator(Modifier.align(Alignment.Center))
            }
            LazyColumn(contentPadding = PaddingValues(12.dp)) {
                items(videos) { video ->
                    VideoRow(
                        video = video,
                        onClick = {
                            // Streaming a real YouTube video requires embedding YouTube's
                            // official player (see README) rather than a raw stream URL.
                            viewModel.play(video, streamUrl = video.watchUrl)
                        },
                        onPlayNext = { viewModel.addToQueueNext(video, streamUrl = video.watchUrl) },
                        onSpeedClick = { speedDialogVideo = video }
                    )
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
    }

    speedDialogVideo?.let {
        PlaybackSpeedDialog(
            current = viewModel.playbackSpeed.collectAsState().value,
            onSelect = { speed -> viewModel.setSpeed(speed); speedDialogVideo = null },
            onDismiss = { speedDialogVideo = null }
        )
    }
}

@Composable
private fun VideoRow(
    video: Video,
    onClick: () -> Unit,
    onPlayNext: () -> Unit,
    onSpeedClick: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }

    ElevatedCard(onClick = onClick, shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(
                model = video.thumbnailUrl,
                contentDescription = video.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(width = 120.dp, height = 68.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(video.title, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                Spacer(Modifier.height(4.dp))
                Text(video.publishedAt.take(10), style = MaterialTheme.typography.bodyMedium)
            }
            Box {
                IconButton(onClick = { menuExpanded = true }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "Options")
                }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    DropdownMenuItem(text = { Text("Play Next") }, onClick = { onPlayNext(); menuExpanded = false })
                    DropdownMenuItem(text = { Text("Playback speed") }, onClick = { onSpeedClick(); menuExpanded = false })
                }
            }
        }
    }
}

@Composable
fun PlaybackSpeedDialog(current: Float, onSelect: (Float) -> Unit, onDismiss: () -> Unit) {
    val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Playback speed") },
        text = {
            Column {
                speeds.forEach { speed ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onSelect(speed) }.padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = speed == current, onClick = { onSelect(speed) })
                        Spacer(Modifier.width(8.dp))
                        Text("${speed}x")
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
