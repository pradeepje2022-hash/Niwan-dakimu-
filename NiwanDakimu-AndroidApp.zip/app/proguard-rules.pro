# Media3
-keep class androidx.media3.** { *; }
# Room
-keep class androidx.room.** { *; }
# Retrofit/Gson models
-keep class com.niwandakimu.app.data.** { *; }
