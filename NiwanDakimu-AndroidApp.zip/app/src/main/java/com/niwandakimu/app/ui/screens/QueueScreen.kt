package com.niwandakimu.app.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.niwandakimu.app.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QueueScreen(viewModel: MainViewModel) {
    val queue by viewModel.queue.collectAsState(initial = emptyList())

    Scaffold(topBar = { TopAppBar(title = { Text("Play Next Queue") }) }) { padding ->
        if (queue.isEmpty()) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Queue is empty. Use \"Play Next\" from a video's menu.")
            }
        } else {
            LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(12.dp)) {
                items(queue) { item ->
                    ListItem(headlineContent = { Text(item.title) })
                    HorizontalDivider()
                }
            }
        }
    }
}
