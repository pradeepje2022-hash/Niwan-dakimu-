package com.niwandakimu.app.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlist_items", primaryKeys = ["playlistId", "videoId"])
data class PlaylistItemEntity(
    val playlistId: Long,
    val videoId: String,
    val title: String,
    val thumbnailUrl: String,
    val watchUrl: String,
    val position: Int
)

/** "Play Next" queue - separate from playlists, cleared as items are consumed. */
@Entity(tableName = "queue_items")
data class QueueItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val videoId: String,
    val title: String,
    val thumbnailUrl: String,
    val watchUrl: String,
    val position: Int
)

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val videoId: String,
    val title: String,
    val thumbnailUrl: String,
    val localFilePath: String,
    val status: String, // QUEUED, DOWNLOADING, COMPLETE, FAILED
    val progressPercent: Int = 0,
    val sourceUrl: String
)
