package com.niwandakimu.app.download

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.niwandakimu.app.data.db.AppDatabase
import com.niwandakimu.app.data.db.DownloadEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File

/**
 * Downloads a media file to app-specific storage (getExternalFilesDir), which
 * requires no runtime storage permission on API 29+ and is automatically
 * cleaned up on uninstall.
 *
 * IMPORTANT: `sourceUrl` must be a direct, licensed media file URL (e.g. audio/
 * video you host yourself, or a podcast-style enclosure link the channel owner
 * provides). This worker deliberately does NOT extract or download YouTube's
 * own protected video streams - doing so violates YouTube's Terms of Service
 * and can get the app removed from Google Play. If Niwan Dakimu wants offline
 * downloads of the actual YouTube uploads, the supported path is publishing a
 * direct downloadable file (e.g. via a CDN/Google Drive link) that this worker
 * can then fetch.
 */
class DownloadWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    companion object {
        const val KEY_VIDEO_ID = "videoId"
        const val KEY_TITLE = "title"
        const val KEY_THUMB = "thumb"
        const val KEY_SOURCE_URL = "sourceUrl"
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val videoId = inputData.getString(KEY_VIDEO_ID) ?: return@withContext Result.failure()
        val title = inputData.getString(KEY_TITLE) ?: ""
        val thumb = inputData.getString(KEY_THUMB) ?: ""
        val sourceUrl = inputData.getString(KEY_SOURCE_URL) ?: return@withContext Result.failure()

        val dao = AppDatabase.getInstance(applicationContext).downloadDao()
        val outFile = File(applicationContext.getExternalFilesDir("downloads"), "$videoId.mp4")

        dao.upsert(
            DownloadEntity(
                videoId = videoId, title = title, thumbnailUrl = thumb,
                localFilePath = outFile.absolutePath, status = "DOWNLOADING",
                progressPercent = 0, sourceUrl = sourceUrl
            )
        )

        try {
            val client = OkHttpClient()
            val request = Request.Builder().url(sourceUrl).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    dao.updateProgress(videoId, 0, "FAILED")
                    return@withContext Result.failure()
                }
                val body = response.body ?: return@withContext Result.failure()
                val total = body.contentLength()
                var written = 0L

                body.byteStream().use { input ->
                    outFile.outputStream().use { output ->
                        val buffer = ByteArray(8 * 1024)
                        var lastReportedPercent = -1
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            written += read
                            if (total > 0) {
                                val percent = ((written * 100) / total).toInt()
                                if (percent != lastReportedPercent) {
                                    lastReportedPercent = percent
                                    dao.updateProgress(videoId, percent, "DOWNLOADING")
                                    setProgressAsync(workDataOf("percent" to percent))
                                }
                            }
                        }
                    }
                }
            }
            dao.updateProgress(videoId, 100, "COMPLETE")
            Result.success()
        } catch (e: Exception) {
            dao.updateProgress(videoId, 0, "FAILED")
            Result.failure()
        }
    }
}
