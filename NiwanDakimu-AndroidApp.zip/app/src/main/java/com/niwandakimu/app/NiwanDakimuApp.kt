package com.niwandakimu.app

import android.app.Application
import com.niwandakimu.app.data.ChannelFeedRepository
import com.niwandakimu.app.data.db.AppDatabase
import com.niwandakimu.app.playback.PlayerController

class NiwanDakimuApp : Application() {

    // TODO: replace with the resolved "UC..." channel ID for Niwan Dakimu
    // (see ChannelFeedRepository doc comment for how to find it).
    val channelId = "UC_REPLACE_WITH_NIWAN_DAKIMU_CHANNEL_ID"

    val database by lazy { AppDatabase.getInstance(this) }
    val feedRepository by lazy { ChannelFeedRepository(channelId) }
    val playerController by lazy { PlayerController(this) }
}
