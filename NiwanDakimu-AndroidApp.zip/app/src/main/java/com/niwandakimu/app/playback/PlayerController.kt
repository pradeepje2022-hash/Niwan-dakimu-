package com.niwandakimu.app.playback

import android.content.ComponentName
import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors

/**
 * Thin wrapper around a MediaController bound to PlaybackService.
 * Use one instance app-wide (e.g. injected via a simple ServiceLocator or Hilt).
 */
class PlayerController(private val context: Context) {

    var controller: MediaController? = null
        private set

    fun connect(onReady: (MediaController) -> Unit) {
        val sessionToken = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, sessionToken).buildAsync()
        future.addListener({
            controller = future.get()
            controller?.let(onReady)
        }, MoreExecutors.directExecutor())
    }

    fun playVideo(videoId: String, title: String, streamUrl: String, thumbnailUrl: String) {
        val mediaItem = MediaItem.Builder()
            .setMediaId(videoId)
            .setUri(streamUrl)
            .setMediaMetadata(
                androidx.media3.common.MediaMetadata.Builder()
                    .setTitle(title)
                    .setArtworkUri(android.net.Uri.parse(thumbnailUrl))
                    .build()
            )
            .build()
        controller?.setMediaItem(mediaItem)
        controller?.prepare()
        controller?.play()
    }

    fun playNext(videoId: String, title: String, streamUrl: String) {
        val mediaItem = MediaItem.Builder()
            .setMediaId(videoId)
            .setUri(streamUrl)
            .setMediaMetadata(androidx.media3.common.MediaMetadata.Builder().setTitle(title).build())
            .build()
        val c = controller ?: return
        val insertIndex = (c.currentMediaItemIndex + 1).coerceAtMost(c.mediaItemCount)
        c.addMediaItem(insertIndex, mediaItem)
    }

    fun togglePlayPause() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun seekTo(positionMs: Long) = controller?.seekTo(positionMs)

    fun setPlaybackSpeed(speed: Float) {
        controller?.setPlaybackSpeed(speed)
    }

    fun stop() = controller?.stop()

    fun release() {
        controller?.release()
        controller = null
    }
}
